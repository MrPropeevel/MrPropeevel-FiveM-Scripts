resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

description 'Realistic vehicle handling for FiveM'
-- MR Propeevel --
version '1.2.0'

client_scripts {
	'config.lua',
	'client.lua'
}